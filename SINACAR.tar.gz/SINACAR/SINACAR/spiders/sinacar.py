# -*- coding: utf-8 -*-
import scrapy
from ..items import SinacarItem


class SinacarSpider(scrapy.Spider):
    name = 'sinacar'
    allowed_domains = ['sina.com.cn']
    start_urls = ['http://db.auto.sina.com.cn/price']

    def parse(self, response):
        """
        处理首页
        """
        # 拿到每个品牌的dl
        dl_brand = response.xpath('//div[@class="data-nav"]//ul/li/dl')
        for dl in dl_brand:
            item = SinacarItem()
            # 品牌名
            item['car_brand'] = dl.xpath('./dt[1]/a/text()').extract()[0]
            car_dd = dl.xpath('./dd')
            link_del = car_dd.pop(0)
            for dd in car_dd:
                item['car_type'] = dd.xpath('./a/text()').extract()[0]
                url = "http:" + dd.xpath('./a/@href').extract()[0]
                yield scrapy.Request(url=url, callback=self.parsea_detail, meta={"item": item})

    def parsea_detail(self, response):
        """
        处理详情页,获取汽车配置信息及价格
        """
        li_list = response.xpath('//div[@class="config-box"]//li[@class="bd clearfix J_type_info J_certain_car"]')
        for li in li_list:
            item = response.meta["item"]
            if len(li.xpath('./div[1]/a/text()').extract()) == 0:
                item['car_configuration'] = "Null"
            else:
                item['car_configuration'] = li.xpath('./div[1]/a/text()').extract()[0]
            if len(li.xpath('./div[4]/text()').extract()) == 0:
                item['car_price'] = "Null"
            else:
                item['car_price'] = li.xpath('./div[4]/text()').extract()[0]
            yield item





